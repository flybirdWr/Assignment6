--
-- Dumping data for table `2014302580368_customer`
--

LOCK TABLES `2014302580368_customer` WRITE;
/*!40000 ALTER TABLE `2014302580368_customer` DISABLE KEYS */;
INSERT INTO `2014302580368_customer` VALUES (1,'weiran','123456','250'),(2,'Bob','123456','650');
/*!40000 ALTER TABLE `2014302580368_customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

--
-- Dumping data for table `2014302580368_pet`
--

LOCK TABLES `2014302580368_pet` WRITE;
/*!40000 ALTER TABLE `2014302580368_pet` DISABLE KEYS */;
INSERT INTO `2014302580368_pet` VALUES (1,'dog','bone','water','ground','play',10),(2,'cat','fish','milk','roof','hug',20),(3,'turtle','fish,shrimp','sea water','sea water','bask',30),(4,'parrot','nuts,seeds','water','tree','fly',40),(5,'hamster','Sunflower seed','water','corner','eat',50),(6,'squirrel','pine cone','water','tree hole,underground','play',60),(7,'rabbit','carrot','water','grassland,underground','eat',70),(8,'snake','mouse','water','hole','bask',80),(9,'lizard','bug','water','tree','bask',90),(10,'fish','aquatic plant','water','water','swim',100),(11,'myna','earthworm','water','tree','fly',110),(12,'canary','millet','water','tree','sing',120);
/*!40000 ALTER TABLE `2014302580368_pet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
