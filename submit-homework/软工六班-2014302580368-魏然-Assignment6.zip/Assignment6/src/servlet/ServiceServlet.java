package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pro.bean.Cart;
import pro.bean.Customer;
import pro.bean.Goods;
import pro.bean.Pet;
import service.dao.CustomerDao;
import service.dao.GoodsDao;
import service.dao.PetDao;
import service.impl.CustomerDaoImpl;
import service.impl.GoodsDaoImpl;
import service.impl.PetDaoImpl;

public class ServiceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String msg="";
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServiceServlet() {    	
        super();           
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		System.out.println(action);
		if(action.equals("login")){
			Login(request,response);
		}else if(action.equals("register")){
			Register(request,response);
		}else if(action.equals("list")){
			List(request,response);
		}else if(action.equals("add")){
			Add(request,response);
		}else if(action.equals("get")){
			Get(request,response);
		}else if(action.equals("cart")){
			Cart(request,response);
		}else if(action!=null&&action.equals("delete")){
			Delete(request,response);
		}else if(action!=null&&action.equals("buy")){
			Buy(request,response);
		}
	}
	
	
	protected void Login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("username");
		String password=request.getParameter("password");
		CustomerDao dao=new CustomerDaoImpl();	
		boolean flag=dao.login(name, password);	
		if(flag){
			Customer c=dao.get(name, password);
			HttpSession session=request.getSession();
			session.setAttribute("Uid", c.getId());
			session.setAttribute("Uname", c.getName());
			session.setAttribute("Ubalance", c.getBalance());
			
			List(request,response);
		}else{
		    msg = "Username or Password error ,please relogin;";
			request.setAttribute("Error", msg);
			request.getRequestDispatcher("/Login.jsp").forward(request, response);
		}
	}
	protected void Register(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("username");
		String password=request.getParameter("password");
		Customer c=new Customer();
		c.setName(name);
		c.setPassword(password);
		CustomerDao dao=new CustomerDaoImpl();	
		if(dao.register(c))
		request.getRequestDispatcher("/Login.jsp").forward(request, response);
	}
	protected void List(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PetDao dao=new PetDaoImpl();
		CustomerDao cdao=new CustomerDaoImpl();	
		List list=dao.list();
		HttpSession session=request.getSession();
		int id=(int) session.getAttribute("Uid");
		Customer c=cdao.get(id);
		request.setAttribute("Ubalance",c.getBalance());
		request.setAttribute("PList", list);
		request.getRequestDispatcher("/Petlist.jsp").forward(request, response);
	}
	protected void Cart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		request.setAttribute("CList", Cart.cart);
		ArrayList clist=Cart.cart;
		request.getRequestDispatcher("/Cart.jsp").forward(request, response);
	}

	protected void Add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String num=request.getParameter("num");
		String id=request.getParameter("id");
		PetDao dao=new PetDaoImpl();
		Pet p=dao.get(new Integer(id).intValue());
		Goods d=new Goods();
		d.setNumber(Integer.parseInt(num));
		d.setPet(p);
		GoodsDao gdao=new GoodsDaoImpl();
		gdao.add(d);
		List(request,response);
	}
	protected void Get(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
		PetDao dao=new PetDaoImpl();
		Pet p=dao.get(new Integer(id).intValue());
		request.setAttribute("Pet", p);
		request.getRequestDispatcher("/Petinfo.jsp").forward(request, response);
	}
	protected void Delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String []ids=request.getParameterValues("ids");	
		GoodsDao gdao=new GoodsDaoImpl();
		gdao.delete(ids);
		Cart(request,response);
	}
	protected void Buy(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String []ids=request.getParameterValues("ids");
		GoodsDao gdao=new GoodsDaoImpl();
		int total=gdao.bill(ids);
		CustomerDao dao=new CustomerDaoImpl();
		HttpSession session=request.getSession();
		int uid=(int) session.getAttribute("Uid");
		dao.buy(uid, total);
		gdao.delete(ids);
		Cart(request,response);
	}
}
