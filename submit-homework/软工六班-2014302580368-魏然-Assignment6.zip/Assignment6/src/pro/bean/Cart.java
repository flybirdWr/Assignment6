package pro.bean;

import java.util.ArrayList;
import java.util.List;

//���ﳵ
public class Cart {
	public static ArrayList<Goods> cart=new ArrayList<Goods>();
}
