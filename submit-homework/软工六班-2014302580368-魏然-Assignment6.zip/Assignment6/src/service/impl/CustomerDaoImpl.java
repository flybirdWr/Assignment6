package service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jdbc.util.DBUtil;
import pro.bean.Customer;
import pro.bean.Pet;
import service.dao.CustomerDao;

public class CustomerDaoImpl implements CustomerDao{

	@Override
	public boolean login(String name, String password) {
		String sql="select * from Customer where name=? and password=?";
		DBUtil util = new DBUtil();
		Connection conn= util.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,name);
			pstmt.setString(2, password);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			util.closeConn(conn);
		}
		return false;
	}

	@Override
	public boolean register(Customer customer) {
		String sql="Insert into Customer(name,password,balance) values(?,?,1000)";
		DBUtil util=new DBUtil();
		Connection conn=util.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, customer.getName());
			pstmt.setString(2, customer.getPassword());
			pstmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			util.closeConn(conn);
		}
		
		return false;
	}

	@Override
	public void buy(int id,int bill) {
		// TODO Auto-generated method stub
		String sql="update Customer set balance=balance-? where id=?";
		DBUtil util=new DBUtil();
		Connection conn=util.getConnection();
		PreparedStatement pstmt;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, bill);
			pstmt.setInt(2,id);
				pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			util.closeConn(conn);
		}
	
	}

	@Override
	public Customer get(String name, String password) {
		// TODO Auto-generated method stub
		String sql="select * from Customer where name=? and password=?";
		DBUtil util = new DBUtil();
		Connection conn= util.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,name);
			pstmt.setString(2, password);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()){
				Customer c =new Customer();
				c.setId(rs.getInt(1));
				c.setName(rs.getString(2));
				c.setPassword(rs.getString(3));
				c.setBalance(rs.getInt(4));
				return c;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			util.closeConn(conn);
		}
		return null;
	}

	public Customer get(int id) {
		// TODO Auto-generated method stub
		String sql="select * from Customer where id=?";
		DBUtil util = new DBUtil();
		Connection conn= util.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,id);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()){
				Customer c =new Customer();
				c.setId(rs.getInt(1));
				c.setName(rs.getString(2));
				c.setPassword(rs.getString(3));
				c.setBalance(rs.getInt(4));
				return c;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			util.closeConn(conn);
		}
		return null;
	}

	

}
