package service.impl;

import java.util.ArrayList;
import java.util.List;

import pro.bean.Cart;
import pro.bean.Goods;
import service.dao.GoodsDao;

public class GoodsDaoImpl implements GoodsDao{

	@Override
	public void delete(String[] s) {
		for(int i=0;i<s.length;i++){
			int id=new Integer(s[i]).intValue();
			ArrayList<Goods> glist=Cart.cart;
			for(int j = 0;j < glist.size(); j++){
				if (( glist.get(j)).getPet().getId()==id) { 		 
					glist.remove(j); 					 
					j--; 					 
				} 
			}
		}
	}

	@Override
	public void add(Goods d) {
		Cart.cart.add(d);
	}

	@Override
	public int bill(String[] s) {
		// TODO Auto-generated method stub
		int total = 0;
		for(int i=0;i<s.length;i++){
			int id=new Integer(s[i]).intValue();
			ArrayList<Goods> glist=Cart.cart;
			for(int j = 0;j < glist.size(); j++){
				if (( glist.get(j)).getPet().getId()==id) { 		 
						total=total+glist.get(j).getPet().getPrice()*glist.get(j).getNumber();				 
										 
				} 
			}
		}
		return total;
	}

}
