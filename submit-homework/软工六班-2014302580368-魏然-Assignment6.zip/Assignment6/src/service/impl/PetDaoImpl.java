package service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import jdbc.util.DBUtil;
import pro.bean.Customer;
import pro.bean.Pet;
import service.dao.PetDao;

public class PetDaoImpl implements PetDao{
	
	@Override
	public void addCart(Customer c) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public List list() {
		String sql="select * from Pet";
		DBUtil util=new DBUtil();
		Connection conn = util.getConnection();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs= stmt.executeQuery(sql);
			List petlist=new ArrayList<Pet>();
			while(rs.next()){
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String eat=rs.getString(3);
				String drink=rs.getString(4);
				String live=rs.getString(5);
				String hobby=rs.getString(6);
				int price=rs.getInt(7);
				Pet p=new Pet();
				p.setId(id);
			    p.setName(name);
			    p.setEat(eat);
			    p.setDrink(drink);
			    p.setLive(live);
			    p.setHobby(hobby);
			    p.setPrice(price);
			    petlist.add(p);
			}
			return petlist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			util.closeConn(conn);
		}
		return null;
	}

	@Override
	public Pet get(int id){
	String sql="select * from Pet where id=?";
	DBUtil util=new DBUtil();
	Connection conn=util.getConnection();
	
	try {
		PreparedStatement stmt=conn.prepareStatement(sql);
		stmt.setInt(1, id);
		ResultSet rs=stmt.executeQuery();
		if(rs.next()){
			String name=rs.getString(2);
			String eat=rs.getString(3);
			String drink=rs.getString(4);
			String live=rs.getString(5);
			String hobby=rs.getString(6);
			int price=rs.getInt(7);
			Pet p=new Pet();
			p.setId(id);
		    p.setName(name);
		    p.setEat(eat);
		    p.setDrink(drink);
		    p.setLive(live);
		    p.setHobby(hobby);
		    p.setPrice(price);
			return p;
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		util.closeConn(conn);
	}
	return null;
}

}
