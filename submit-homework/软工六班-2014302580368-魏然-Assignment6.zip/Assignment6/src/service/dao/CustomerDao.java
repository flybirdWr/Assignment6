package service.dao;

import pro.bean.Customer;

public interface CustomerDao{
	public boolean login(String name,String password);
	public boolean register(Customer customer);
	public Customer get(String name,String password);
	public Customer get(int id);
	public void buy(int id,int bill);
}
