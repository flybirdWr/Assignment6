package service.dao;

import java.util.List;
import pro.bean.Customer;
import pro.bean.Pet;

public interface PetDao{
	public void addCart(Customer c);
	public List list(); 
	public Pet get(int id);
}
