package service.dao;

import java.util.List;

import pro.bean.Goods;


public interface GoodsDao {
	public void delete(String[] s);
	public void add(Goods d);
	public int bill(String[] s);
}
